/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   redirect.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 19:40:26 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

int redirect_output(t_word *word_list)
{
	int saved_stdout;
	int fd;

	saved_stdout = dup(STDOUT_FILENO);
	while (word_list != NULL)
	{
		if (ft_strcmp(word_list->type, "redirect") == 0)
		{
			if (ft_strcmp(word_list->value, ">") == 0)
			{
				if (word_list->next == NULL)
				{
					perror("syntax error");
					return (-1);
				}
				word_list = word_list->next;
				fd = open(word_list->value, O_WRONLY | O_CREAT | O_TRUNC, 0666);
        		if (fd < 0)
       		 	{
          			perror("open");
          			return (-1);
        		}
				dup2(fd, STDOUT_FILENO);
				close(fd);
			}
			else if (ft_strcmp(word_list->value, ">>") == 0)
			{
				if (word_list->next == NULL)
				{
					perror("syntax error");
					return (-1);
				}
				word_list = word_list->next;
				fd = open(word_list->value, O_WRONLY | O_CREAT | O_APPEND, 0666);
        		if (fd < 0)
        		{
          			perror("open");
          			return (-1);
        		}
				dup2(fd, STDOUT_FILENO);
				close(fd);
			}
		}
		word_list = word_list->next;
	}
	return(saved_stdout);
}

void restore_output(int saved_stdout)
{
	dup2(saved_stdout, STDOUT_FILENO);
	close(saved_stdout);
	return;
}

int redirect_input(t_word *word_list)
{
	int saved_stdin;
	int fd;

	saved_stdin = dup(STDIN_FILENO);
	while (word_list != NULL)
    {
        if (ft_strcmp(word_list->type, "redirect") == 0 && ft_strcmp(word_list->value, "<") == 0)
        {
            if (word_list->next == NULL)
            {
                perror("syntax error");
                return (-1);
            }
            word_list = word_list->next;
            fd = open(word_list->value, O_RDONLY);
            if (fd < 0)
            {
                perror("open");
                return (-1);
            }
            dup2(fd, STDIN_FILENO);
            close(fd);
        }
        word_list = word_list->next;
    }
    return(saved_stdin);
}

void restore_input(int saved_stdin)
{
	dup2(saved_stdin, STDIN_FILENO);
	close(saved_stdin);
	return;
}
