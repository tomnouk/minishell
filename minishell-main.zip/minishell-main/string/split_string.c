/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   split_string.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/06/14 17:43:21 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

char **split_string(const char *s, t_env_var *env)
{
    char **words;
    int i = 0;
    size_t j = 0;

    words = malloc((ft_strlen(s) + 1) * sizeof(char *));
    if (words == NULL)
        return(NULL);
    while (s[i] != '\0')
    {
        while (s[i] == ' ' && s[i] != '\0')
        {
            i++;
        }
        if (s[i] == 34)
        {
            words[j] = double_quote(s, &i);
            if (words[j] == NULL)
                return(free_string(words, j));
            if (ft_strchr(words[j], 36) != NULL)
            {
                words[j] = sub_env_var(words[j], env);
                if (words[j] == NULL)
                    return(free_string(words, j));
            }
            j++;
        }
        else if (s[i] == 39)
        {
            words[j] = single_quote(s, &i);
            if (words[j] == NULL)
                return(free_string(words, j));
            j++;
        }
        else if (s[i] == 60)
        {
            words[j] = less(s, &i);
            if (words[j] == NULL)
                return(free_string(words, j));
            j++;
        }
        else if (s[i] == 62)
        {
            words[j] = grate(s, &i);
            if (words[j] == NULL)
                return(free_string(words, j));
            j++;
        }
        else if (s[i] != '\0')
        {
            words[j] = space(s, &i);
            if (words[j] == NULL)
                return(free_string(words, j));
            if (ft_strchr(words[j], 36) != NULL)
            {
                words[j] = sub_env_var(words[j], env);
                if (words[j] == NULL)
                    return(free_string(words, j));
            }
            j++;
        }
    }
    words[j] = NULL;
    while (j < ft_strlen(s) + 1)
    {
        words[j] = NULL;
        j++;
    }
    return(words);
}

/*
int main()
{
    char *s = "cio  aa<<aaa\"ciao  <<<<    bb\"aaaq><<   \"come stai\"<";
    //char *s = "cio   aa<<aaa";
    char **words = split(s);
    int i = 0;
    while (words[i] != NULL)
    {
        printf("%s\n", words[i]);
        i++;
    }
    clean_all(words);
    return(0);
}*/