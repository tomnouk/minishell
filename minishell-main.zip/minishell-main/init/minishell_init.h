/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell_init.h                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 11:45:34 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 11:45:41 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_INIT_H
# define MINISHELL_INIT_H

void    init_env(t_env_var **env, char **env_sys);
void	init_value(t_env_var **env, char **env_sys, char *prompt);
void    handle_sigint(int sig);
void    handle_sigquit(int sig);

#endif
