/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_env.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 19:40:26 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

static void error_exit(t_env_var **env)
{
  ft_putstr_fd("Error: malloc failed\n", 2);
  clean_env_var(env);
  exit(1);
  return;
}

static void error_exit_two(t_env_var **env, t_env_var *new)
{
  ft_putstr_fd("Error: malloc failed\n", 2);
  free(new->name);
  clean_env_var(env);
  exit(1);
  return;
}

static void ft_env_add_init(t_env_var **env, char *s1, char *s2)
{
  t_env_var *temp;
  t_env_var *new;

  temp = *env;
  new = (t_env_var *)malloc(sizeof(t_env_var));
  if (new == NULL)
    error_exit(env);
  new->visible = 0;
  new->name = ft_strdup(s1);
  if (new->name == NULL)
    error_exit(env);
  if (s2 == NULL)
    new->value = ft_strdup("");
  else
    new->value = ft_strdup(s2);
  if (new->value == NULL)
    error_exit_two(env, new);
  new->next = NULL;
  if (*env == NULL)
  {
    *env = new;
    return;
  }
  while (temp->next != NULL)
		temp = temp->next;
	temp->next = new;
  return;
}

void  init_env(t_env_var **env, char **env_sys)
{
  int i;
  char **parts;

  i = 0;
  while (env_sys[i] != NULL)
  {
    parts = ft_divide_env(env_sys[i]);
    if (parts == NULL)
    {
      ft_putstr_fd("Error: malloc failed\n", 2);
      clean_env_var(env);
      exit(1);
    }
    ft_env_add_init(env, parts[0], parts[1]);
    clean_string(parts);
    i++;
  }
  return;
}
