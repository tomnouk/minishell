/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   exit.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 19:40:26 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

void	exit_one(char *input, t_env_var **env)
{
	free(input);
	clean_env_var(env);
	exit(1);
	return;
}

void	exit_two(char **s, char *input, t_env_var **env)
{
	free(input);
	clean_env_var(env);
	clean_string(s);
	exit(1);
	return;
}

void	exit_three(char *input, t_env_var **env, t_word **word_list)
{
	free(input);
	clean_env_var(env);
	clean_list(word_list);
	exit(1);
	return;
}