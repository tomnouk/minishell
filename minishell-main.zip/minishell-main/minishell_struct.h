/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell_struct.h                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 11:45:34 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 11:45:41 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_STRUCT_H
# define MINISHELL_STRUCT_H

#define DEFAULT_WORD ((t_word *)(&(t_word){ "default_type", "default_value", NULL }))

typedef struct word
{
    char *type;
    char *value;
    struct word *next;
} t_word;

typedef struct env_var
{
    char *name;
    char *value;
    int visible;
    struct env_var *next;
} t_env_var;

#endif
