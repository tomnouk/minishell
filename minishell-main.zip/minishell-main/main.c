/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/06/14 17:39:14 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	main(int argc, char **argv, char **env_sys)
{
	char *input;
	char prompt[PATH_MAX] = "";
	char **s;
	t_env_var *env;
	t_word *word_list;

	init_value(&env, env_sys, prompt);
	(void)argc;
	(void)argv;
	while (1)
	{
		input = readline(prompt);
		if (input == NULL)
			exit_one(input, &env);
		s = split_string(input, env);
		if (s == NULL)
			exit_one(input, &env);
		word_list = create_list(s, &word_list);
		if (word_list == NULL)
			exit_two(s, input, &env);

		print_list(word_list); //debug

		if (analyze_command(word_list, prompt, &env) == -1)
			exit_three(input, &env, &word_list);
		clean_list(&word_list);
		rl_on_new_line();
		add_history(input);
		free(input);
	}
	//rl_clear_history();
	return (0);
}
