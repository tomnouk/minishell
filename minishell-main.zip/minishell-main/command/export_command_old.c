/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   export_command.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 19:40:26 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

int search_valid_env_ex(char *s)
{
  int i;

  i = 0;
  while (s[i] != '\0' && s[i] != '=')
  {
    if ((s[i] == '+') && ((s[i+1]) == '='))
      return(0);
    if (ft_isenvvar(s[i]) == 0)
      return(-1);
    i++;
  }
  return(0);
}

void ft_env_print_ex(t_env_var **env)
{
  t_env_var *temp = *env;

  while (temp != NULL)
  {
    printf("declare -x ");
    printf("%s=\"%s\"\n", temp->name, temp->value);
    temp = temp->next;
  }
  return;
}

int ft_env_add(t_env_var **env, char *s1, char *s2)
{
  t_env_var *temp;
  t_env_var *new;

  temp = *env;
  new = (t_env_var *)malloc(sizeof(t_env_var));
  if (new == NULL)
  {
    ft_putstr_fd("Error: malloc failed\n", 2);
    return(-1);
  }
  new->name = ft_strdup(s1);
  if (new->name == NULL)
  {
    ft_putstr_fd("Error: malloc failed\n", 2);
    return(-1);
  }
  if (s2 == NULL)
    new->value = ft_strdup("");
  else
    new->value = ft_strdup(s2);
  if (new->value == NULL)
  {
    ft_putstr_fd("Error: malloc failed\n", 2);
    free(new->name);
    return(-1);
  }
  new->next = NULL;
  if (*env == NULL)
  {
    *env = new;
    return(0);
  }
  while (temp->next != NULL)
	{
		temp = temp->next;
	}
	temp->next = new;
  return(0);
}

int search_already(t_env_var **env, char *s1, char *s2)
{
  t_env_var *temp;

  temp = *env;
  while (temp != NULL)
  {
    if (ft_strcmp(temp->name, s1) == 0)
    {
      free(temp->value);
      if (s2 == NULL)
        temp->value = ft_strdup("");
      else
        temp->value = ft_strdup(s2);
      if (temp->value == NULL)
      {
        ft_putstr_fd("Error: malloc failed\n", 2);
        return(-1);
      }
      return(1);
    }
    temp = temp->next;
  }
  return(0);
}

int  export_env(t_word *temp, t_env_var **env)
{
  char **parts;

  parts = ft_split(temp->value, '=');
  if (search_already(env, parts[0], parts[1]) == 1)
  {
    clean_string(parts);
    return(0);
  }
  if (ft_env_add(env, parts[0], parts[1]) < 0)
  {
    clean_string(parts);
    return(-1);
  }
  clean_string(parts);
  return(0);
}

int search_operator(t_word *word_list)
{
  int fd;
  
  if ((word_list->next != NULL) && (ft_strcmp(word_list->next->type, "redirect") == 0))
  {
    word_list = word_list->next;
    if (((ft_strcmp(word_list->value, ">") == 0) || (ft_strcmp(word_list->value, ">>") == 0)) && (word_list->next != NULL))
    {
      word_list = word_list->next;
      fd = open(word_list->value, O_WRONLY | O_CREAT | O_TRUNC, 0666);
      if (fd < 0)
      {
        perror("file write error");
        return (-1);
      }
      close(fd);
      return(1);
    }
    else if (((ft_strcmp(word_list->value, "<") == 0) || (ft_strcmp(word_list->value, "<<") == 0)) && (word_list->next != NULL))
    {
      word_list = word_list->next;
      if (access(word_list->value, F_OK | R_OK) != 0)
      {
        perror("no file or directory");
        return (-1);
      }
      return(1);
    }
    else
    {
      perror("export: syntax error");
      return (-1);
    }
  }
  return(0);
}

int  export_command(t_word *word_list, t_env_var **env)
{
  if (word_list->next != NULL)
  {
    word_list = word_list->next;
    if (ft_strcmp(word_list->type, "argument") != 0)
    {
      perror("unset: syntax error");
      return(0);
    }
  }
  else
  {
    ft_env_print_ex(env);
    return(0);
  }
  while(word_list != NULL)
  {
    if ((search_valid_env_ex(word_list->value) == 0) && (ft_strcmp(word_list->type, "argument") == 0))
    {
      if (search_operator(word_list) < 0)
        return(0);
      if (export_env(word_list, env) < 0)
        return(-1);
    }
    else
    {
      if (ft_strcmp(word_list->type, "argument") == 0)
      {
        ft_putstr_fd("Error: invalid env var\n", 2);
        return(0);
      }
    }
    word_list = word_list->next;
  }
  return(0);
}