/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   echo_command.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 19:40:26 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

static char	*ft_strjoin_mod(char *s1, char *s2)
{
	size_t	i;
	size_t	j;
	size_t	z;
	char	*dest;

	z = 0;
	i = ft_strlen(s1);
	j = ft_strlen(s2);
	dest = malloc((i + j + 1) * sizeof(char));
	if (dest == NULL)
  {
    if (s1 != NULL)
      free(s1);
		return (NULL);
  }
	while (z < i)
	{
		dest[z] = s1[z];
		z++;
	}
	while (z < (i + j))
	{
		dest[z] = s2[z - i];
		z++;
	}
	dest[z] = '\0';
  if (s1 != NULL)
    free(s1);
	return (dest);
}

static int  print_command(char *output, int option)
{
  //print_output(output, STDOUT_FILENO, option);
  if (option == 0)
  {
    write(STDOUT_FILENO, output, ft_strlen(output));
    write(STDOUT_FILENO, "\n", 1);
  }
  else
  {
    write(STDOUT_FILENO, output, ft_strlen(output));
  }
  close(STDOUT_FILENO);
  return(0);
}

int  echo_command(t_word *word_list)
{
  t_word  *temp;
  char  *output;
  char  *old_output;
  int option;

  option = 0;
  output = ft_strdup("");
  if (output == NULL)
    return(-1);
  temp = word_list->next;
  if (temp != NULL && ft_strcmp(temp->value, "-n") == 0)
  {
    option = 1;
    temp = temp->next;
  }
  while (temp != NULL)
  {
    if (ft_strcmp(temp->type, "argument") == 0)
    {
      old_output = output;
      if (ft_strcmp(output, "\0") != 0)
      {
        output = ft_strjoin_mod(old_output, " ");
        if (output == NULL)
          return(-1);
        old_output = output;
      }
      output = ft_strjoin_mod(old_output, temp->value);
      if (output == NULL)
        return(-1);
    }
    temp = temp->next;
  }
  if (print_command(output, option) == -1)
  {
    free(output);
    return(-1);
  }
  free(output);
  return(0);
}

/*
int  echo_command(t_word *word_list)
{
  char  *output;
  char  *old_output;
  int option;
  int operator;

  option = 0;
  operator = 0;
  output = ft_strdup("");
  if (output == NULL)
    return(-1);
  word_list = word_list->next;
  if (word_list != NULL && ft_strcmp(word_list->value, "-n") == 0)
  {
    option = 1;
    word_list = word_list->next;
  }
  while (word_list != NULL)
  {
    if (ft_strcmp(word_list->type, "operator") == 0)
    {
      if (ft_strcmp(word_list->value, ">") == 0)
      {
        if (word_list->next == NULL)
        {
          perror("minishell: syntax error near unexpected token `newline'");
          return(0);
        }
        word_list = word_list->next;
        operator = 1;
      }
      else if (ft_strcmp(word_list->value, ">>") == 0)
      {
        if (word_list->next == NULL)
        {
          perror("minishell: syntax error near unexpected token `newline'");
          return(0);
        }
        word_list = word_list->next;
        operator = 2;
      } //da finire
      else if ((ft_strcmp(word_list->value, "<") == 0) || (ft_strcmp(word_list->value, "<<") == 0))
      {
        if (word_list->next == NULL)
        {
          perror("minishell: syntax error near unexpected token `newline'");
          return(0);
        }
        word_list = word_list->next;
        return(0);
      }
    }
    else if (ft_strcmp(word_list->type, "argument") == 0)
    {
      old_output = output;
      if (ft_strcmp(output, "\0") != 0)
      {
        output = ft_strjoin_mod(old_output, " ");
        if (output == NULL)
          return(-1);
        old_output = output;
      }
      output = ft_strjoin_mod(old_output, word_list->value);
      if (output == NULL)
        return(-1);
    }
    word_list = word_list->next;
  }
  write(1, "qui", 3);

  if (print_command(output, word_list, option, operator) == -1)
  {
    free(output);
    return(-1);
  }
  free(output);
  return(0);
}
*/