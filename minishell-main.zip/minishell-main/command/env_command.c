/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   env_command.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 19:40:26 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

void  env_command(t_word *word_list, t_env_var *env)
{
  if (word_list->next != NULL)
  {
    printf("env: too many arguments\n");
    return;
  }
  while (env != NULL)
  {
    if (env->visible == 0)
      printf("%s=%s\n", env->name, env->value);
    env = env->next;
  }
  return;
}
