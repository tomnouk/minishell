/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   analyze_command.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 19:40:26 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

int analyze_command(t_word *word_list, char *prompt, t_env_var **env)
{
	int saved_stdout;
  int saved_stdin;
  t_word *temp;
  
  temp = word_list;
  while ((temp != NULL) && ft_strcmp(temp->type, "command") != 0)
    temp=temp->next;
  if (temp == NULL)
    return(0);
  if ((saved_stdout = redirect_output(word_list)) < 0)
    return(0);
  if ((saved_stdin = redirect_input(word_list)) < 0)
    return(0);
  if (ft_strcmp(temp->value, "echo") == 0)
  {
    if (echo_command(word_list) < 0)
      return (-1);
  }
  else if (ft_strcmp(temp->value, "cd") == 0)
  {
    if (cd_command(word_list, prompt, env) < 0)
      return (-1);
  }
  else if (ft_strcmp(temp->value, "pwd") == 0)
  {
    if (pwd_command(word_list) < 0)
      return (-1);
  }
  else if (ft_strcmp(temp->value, "export") == 0)
  {
    if (export_command(word_list, env) < 0)
      return (-1);
  }
  else if (ft_strcmp(temp->value, "unset") == 0)
  {
    unset_command(word_list, env);
  }
  else if (ft_strcmp(temp->value, "env") == 0)
  {
    env_command(word_list, *env);
  }
  else if (ft_strcmp(temp->value, "exit") == 0)
  {
    restore_output(saved_stdout);
    clean_env_var(env);
    clean_list(&word_list);
    exit(0);
  }
	else if (temp != NULL)
	{
    if (other_command(word_list, *env) < 0)
      return (-1);
  }
  restore_output(saved_stdout);
  restore_input(saved_stdin);
  return(0);
}