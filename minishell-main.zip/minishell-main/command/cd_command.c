/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cd_command.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 19:40:26 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

int  change_env_oldpwd(t_env_var **env)
{
  char cwd[PATH_MAX] = "";
  t_env_var *temp;

  temp = *env;
  getcwd(cwd, sizeof(cwd));
  while (temp != NULL)
  {
    if (ft_strcmp(temp->name, "OLDPWD") == 0)
    {
      free(temp->value);
      temp->value = ft_strdup(cwd);
      if (temp->value == NULL)
        return(-1);
    }
    temp = temp->next;
  }
  return(0);
}

int  change_env_pwd(char *cwd, t_env_var **env)
{
  t_env_var *temp;

  temp = *env;
  while (temp != NULL)
  {
    if (ft_strcmp(temp->name, "PWD") == 0)
    {
      free(temp->value);
      temp->value = ft_strdup(cwd);
      if (temp->value == NULL)
        return(-1);
    }
    temp = temp->next;
  }
  return(0);
}

int  cd_command(t_word *word_list, char *prompt, t_env_var **env)
{
  char cwd[PATH_MAX] = "";

  if (word_list->next == NULL)
  {
    perror("write a path to change directory");
    return(0);
  }
  word_list = word_list->next;
  if (change_env_oldpwd(env) < 0)
    return(-1);
  if (chdir(word_list->value) == 0)
	{
		ft_memset(cwd, '\0', sizeof(cwd));
		if (getcwd(cwd, sizeof(cwd)) != NULL)
		{
      ft_memset(prompt, '\0', ft_strlen(prompt));
      ft_strlcat(prompt, cwd, sizeof(cwd));
      ft_strlcat(prompt, "$ ", sizeof(cwd));
    }
    else
    {
      perror("getcwd");
      return(-1);
    }
    rl_on_new_line();
    rl_replace_line(prompt, 1);
    //rl_redisplay();
  }
  else
  {
    perror("cd");
    return(0);
  }
  if (change_env_pwd(cwd, env) < 0)
    return(-1);
  return(0);
}
