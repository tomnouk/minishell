/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pwd_command.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 19:40:26 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

static void  print_dir(char *output, t_word *word_list, int operator)
{
  int fd;

  if (ft_strcmp(word_list->type, "file") == 0)
  {
    if (operator == 1)
    {
      fd = open(word_list->value, O_WRONLY | O_CREAT | O_TRUNC, 0666);
      write(fd, output, ft_strlen(output));
      close(fd);
    }
    else if (operator == 2)
    {
      fd = open(word_list->value, O_WRONLY | O_CREAT | O_APPEND, 0666);
      write(fd, output, ft_strlen(output));
      close(fd);
    }
  }
  return;
}

int pwd_command(t_word *word_list)
{
  char cwd[PATH_MAX] = "";

  if (word_list->next != NULL)
    word_list = word_list->next;
  ft_memset(cwd, '\0', sizeof(cwd));
  while (word_list != NULL)
  {
    if (ft_strcmp(word_list->type, "redirect") == 0)
    {
      if (ft_strcmp(word_list->value, ">") == 0)
      {
        if (word_list->next == NULL)
        {
          perror("Errore in input");
          return (0);
        }
        word_list = word_list->next;
        if (getcwd(cwd, sizeof(cwd)) != NULL)
        {
          print_dir(cwd, word_list, 1);
          return (0);
        }
      }
      else if (ft_strcmp(word_list->value, ">>") == 0)
      {
        if (word_list->next == NULL)
        {
          perror("Errore in input");
          return (0);
        }
        word_list = word_list->next;
        if (getcwd(cwd, sizeof(cwd)) != NULL)
        {
          print_dir(cwd, word_list, 2);
          return (0);
        }
      }
    }
    word_list = word_list->next;
  }
  if (getcwd(cwd, sizeof(cwd)) != NULL)
    printf("%s\n",cwd);
  return (0);
}
