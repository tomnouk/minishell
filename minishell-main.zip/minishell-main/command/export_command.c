/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   export_command.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 19:40:26 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

void ft_env_print_ex(t_env_var **env)
{
  t_env_var *temp = *env;

  while (temp != NULL)
  {
    write(STDOUT_FILENO, "declare -x ", 11);
    write(STDOUT_FILENO, temp->name, ft_strlen(temp->name));
    write(STDOUT_FILENO, "=\"", 2);
    write(STDOUT_FILENO, temp->value, ft_strlen(temp->value));
    write(STDOUT_FILENO, "\"\n", 2);
    temp = temp->next;
  }
  return;
}

int search_already(t_env_var **env, char *s1, char *s2)
{
  t_env_var *temp;

  temp = *env;
  while (temp != NULL)
  {
    if (ft_strcmp(temp->name, s1) == 0)
    {
      free(temp->value);
      if (s2 == NULL)
        temp->value = ft_strdup("");
      else
        temp->value = ft_strdup(s2);
      if (temp->value == NULL)
      {
        ft_putstr_fd("Error: malloc failed\n", 2);
        return(-1);
      }
      return(1);
    }
    temp = temp->next;
  }
  return(0);
}

int search_valid_env_ex(char *s)
{
  int i;

  i = 0;
  while (s[i] != '\0' && s[i] != '=')
  {
    if ((s[i] == '+') && ((s[i+1]) == '='))
      return(1);
    if (ft_isenvvar(s[i]) == 0)
      return(-1);
    i++;
  }
  return(0);
}

int ft_env_add(t_env_var **env, char *s1, char *s2)
{
  t_env_var *temp;
  t_env_var *new;

  temp = *env;
  new = (t_env_var *)malloc(sizeof(t_env_var));
  if (new == NULL)
  {
    ft_putstr_fd("Error: malloc failed\n", 2);
    return(-1);
  }
  new->name = ft_strdup(s1);
  if (new->name == NULL)
  {
    ft_putstr_fd("Error: malloc failed\n", 2);
    return(-1);
  }
  if (s2 == NULL)
    new->value = ft_strdup("");
  else
    new->value = ft_strdup(s2);
  if (new->value == NULL)
  {
    ft_putstr_fd("Error: malloc failed\n", 2);
    free(new->name);
    return(-1);
  }
  new->next = NULL;
  if (*env == NULL)
  {
    *env = new;
    return(0);
  }
  while (temp->next != NULL)
	{
		temp = temp->next;
	}
	temp->next = new;
  return(0);
}

int  ft_append_env(char **parts, t_word *temp, t_env_var **env)
{
  char *new_value;
  
  parts[0][ft_strlen(parts[0]) - 1] = '\0';
  if (search_already(env, parts[0], parts[1]) == 1)
  {
    new_value = ft_strjoin(temp->value, parts[1]);
    if (temp->value == NULL)
    {
      ft_putstr_fd("Error: malloc failed\n", 2);
      return(-1);
    }
    free(temp->value);
    temp->value = new_value;
    clean_string(parts);
    return(0);
  }
  if (ft_env_add(env, parts[0], parts[1]) < 0)
  {
    clean_string(parts);
    return(-1);
  }
  clean_string(parts);
  return(0);
}

int  export_env(t_word *temp, t_env_var **env, int append)
{
  char **parts;

  parts = ft_divide_env(temp->value);
  if (parts == NULL)
    return(-1);
  if (append == 1)
    return(ft_append_env(parts, temp, env));
  if (search_already(env, parts[0], parts[1]) == 1)
  {
    clean_string(parts);
    return(0);
  }
  if (ft_env_add(env, parts[0], parts[1]) < 0)
  {
    clean_string(parts);
    return(-1);
  }
  clean_string(parts);
  return(0);
}

int  export_command(t_word *word_list, t_env_var **env)
{
  t_word *temp;
  int arg;
  int append;

  append = 0;
  arg = 0;
  temp = word_list;
  while ((temp != NULL))
  {
    if (ft_strcmp(temp->type, "argument") == 0)
      arg = 1;
    temp=temp->next;
  }
  if (arg == 0)
  {
    ft_env_print_ex(env);
    return(0);
  }
  while(word_list != NULL)
  {
    append = search_valid_env_ex(word_list->value);
    if ((append != -1) && (ft_strcmp(word_list->type, "argument") == 0))
    {
      if (export_env(word_list, env, append) < 0)
        return(-1);
    }
    else
    {
      if (ft_strcmp(word_list->type, "argument") == 0)
      {
        ft_putstr_fd("Error: invalid env var\n", 2);
        return(0);
      }
    }
    word_list = word_list->next;
  }
  return(0);
}